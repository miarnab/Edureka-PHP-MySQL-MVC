<?php
	echo strpos("Hard work brings success", "success");
?>
