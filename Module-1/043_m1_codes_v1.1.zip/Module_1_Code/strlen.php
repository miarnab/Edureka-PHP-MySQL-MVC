<?php
$string_length ="This function is used to 
				calculate the length of the string 
				including spaces.";
echo strlen($string_length);
?>
