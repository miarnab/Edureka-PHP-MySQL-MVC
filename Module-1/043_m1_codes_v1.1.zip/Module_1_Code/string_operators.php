<?php
	//Concat a string using "."
	$firstname="Lorna";
	$lastname="Waggoner";
	echo $firstname . " " . $lastname;
?>
