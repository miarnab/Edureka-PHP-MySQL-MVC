<?php
	$count=1;
	
	While($count<=10){
		Print("Count is $count<br>");
		$count = $count + 1;
	}
?>