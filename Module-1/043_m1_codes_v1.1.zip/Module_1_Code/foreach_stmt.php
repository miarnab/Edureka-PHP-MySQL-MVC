<?php
	$months = array("January","February","March","April",
					"May","June","July","August",
					"September","October","November","December");

	foreach($months as $value){
		echo "$value <br>";
	}
?>