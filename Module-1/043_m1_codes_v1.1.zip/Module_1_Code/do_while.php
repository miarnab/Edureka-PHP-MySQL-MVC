<?php
	$count=0;
	do{
		Print("Count is $count<br>");
		$count = $count + 1;
	} While($count<=10)
?>

