<?php
for($x=1, $y=1, $z=1; //initial expression
	$y<10, $z<10;    //termination checks
	$x = $x +1,$y=$y+2,$z=$z + 3 //loop-end expressions
)
	Print("$x, $y, $z<br>");
?>

