<?php
$day = "10/25/2014"; 
$dayarr = split('[/.-]',$day); 
print "$dayarr[0] <br />";
print "$dayarr[1] <br />";
print "$dayarr[2] <br />";
?>