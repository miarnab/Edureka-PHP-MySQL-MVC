<?php
echo date("m/d/Y ", time());
echo "<br>";
echo "Today is ";
echo date("j F Y, \a\\t g.i a", time());
?>
