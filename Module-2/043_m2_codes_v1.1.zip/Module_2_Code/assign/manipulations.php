<?php
require "functions.php";
echo "Addition of two numbers is ". Addition(3.75, 5.645);
echo "<br/>";
echo "Product of two numbers is ". Multiplication(3, 5);
?>
