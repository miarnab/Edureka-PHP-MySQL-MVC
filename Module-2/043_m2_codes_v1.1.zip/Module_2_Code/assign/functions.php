<?php

function addition($a, $b){
	return $a + $b;
}

function multiplication($a, $b){
	return $a * $b;
}
?>
