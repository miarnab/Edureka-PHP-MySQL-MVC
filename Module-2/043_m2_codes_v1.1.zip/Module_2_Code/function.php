<html>
<head>
<title>User defined functions</title>
</head>
<body>
<?php
function displaymessage()
{
  echo "This is user defined function with single echo statement.";
}
displaymessage ();
?>
</body>
</html>
