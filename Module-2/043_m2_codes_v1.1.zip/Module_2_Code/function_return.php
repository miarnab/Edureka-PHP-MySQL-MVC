<html>
<head>
<title> PHP Function with three Parameters</title>
</head>
<body>
<?php
function addition($value1,$value2,$value3)
{
  $result = $value1+ $value2+$value3;
  return $result;
}
$sum = addition (10,20,30);
echo "Returned value from the function is: $sum ";
?>
</body>
</html>
