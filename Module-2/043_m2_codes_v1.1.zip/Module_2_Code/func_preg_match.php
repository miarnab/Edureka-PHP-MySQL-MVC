<?php
$string = "abcdefghijklmnopqrstuvwxyz1234567890";
echo preg_match("/abc/",$string);
?>
