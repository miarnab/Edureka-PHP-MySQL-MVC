<?php
$keywords = "This book is *really* good.";
$keywords = preg_quote($keywords, '/');
echo $keywords;
?>
